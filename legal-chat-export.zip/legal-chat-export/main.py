# Launcher for PyCharm: starts a Tkinter GUI for local legal chat (RAG + Ollama)
from app.gui_tk import run_gui

if __name__ == "__main__":
    run_gui()
